package Servlet;

import com.adyen.model.checkout.PaymentMethodDetails;
import module.*;
import com.adyen.model.checkout.PaymentsDetailsRequest;
import com.adyen.model.checkout.PaymentsRequest;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(urlPatterns = "/makepaymentsdetails.do")
public class MakepaymentsDetailsServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        //Similar deployment as MakePaymentServlet
        //Pass Json body to servlet. (Different encoding schema.)
        //Reference: https://www.edureka.co/community/31716/httpservletrequest-get-json-post-data

        StringBuilder sb = new StringBuilder();
        BufferedReader br = request.getReader();
        String str = null;

        while ((str = br.readLine()) != null) {
            sb.append(str);
        }
        String json = sb.toString();
        System.out.println("Detailedmethod info:"+json+"\n");

        //As mentioned in makepaymentsServelt, it would be more complicated if using my solution to structure
        //the PaymentsDetailsRequest, as there are at list three scenarios, 1. redirect with getHTTP, 2. redirect with PostHTTP,
        //and 3. stata.data from onaddtionaldetails event. Details refer to word documentation.


        /*In this part, only onadditionaldetails event should be considered. Which should be native 3ds2
        As i tested  my solution, i need to add details array and paymentdata into the PaymentMethodDetails as below:
        PaymentsDetailsRequest request1=new PaymentsDetailsRequest();

        request1.setDetails();
        request1.setChallengeResult();
        request1.setFingerPrint()


        As article mentioend only to pass state.data, dropin.handleaction should have handle the data. But in redirect we need to handle by ourself.

        Since there are multiple combinations which would cause hugh testing one by one, and the handle data is also time-consuming.
        I refer to the example code. And I studied from:https://www.tutorialspoint.com/gson/gson_custom_adapters.htm

        Here is the understanding after learning above tutorial:
        It created a new adopter: new PaymentMethodDetailsDeserializer()
        This would change PaymentMethodDetails（interface could not create the obejct directly into a new format PaymentMethodDetails(which is PaymentMethodDetailsDeserializer)
        For detailed format of PaymentMethodDetailsDeserializer, in source code
        object PaymentMethodDetailsDeserializer is equal to AAA:jsonDeserializationContext.deserialize(jsonElement, DefaultPaymentMethodDetails.class).
        The function of AAA is to change json to DefaultPaymentMethodDetails object which implements the PaymentMethodDetails Interface。(Object created).

        Then user gson builder to pass json and deserialize to PaymentsDetailsRequest.class (Which is actually a DefaultPaymentMethodDetails class implemented.)


        */


        GsonBuilder builder =new GsonBuilder();
        builder.registerTypeAdapter(PaymentMethodDetails.class,new PaymentMethodDetailsDeserializer());
        Gson gson = builder.create();

        PaymentsDetailsRequest prequest =gson.fromJson(json, PaymentsDetailsRequest.class);


        String presponse = PaymentsDetails.makePaymentDetailsRequest(prequest);



        //Pass String post response in servlet. Reference:https://beginnersbook.com/2013/05/servlet-response/
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println(presponse);
        out.close();


    }

}
