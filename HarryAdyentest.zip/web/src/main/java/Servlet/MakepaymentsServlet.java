package Servlet;

import com.adyen.model.checkout.DefaultPaymentMethodDetails;
import com.adyen.model.checkout.PaymentMethodDetails;
import com.adyen.model.checkout.PaymentsDetailsRequest;
import com.adyen.model.checkout.details.PayPalDetails;
import com.google.gson.*;
import module.*;
import com.adyen.model.checkout.PaymentsRequest;
import org.json.JSONException;
import org.json.JSONObject;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Type;



@WebServlet(urlPatterns = "/makepayments.do")
public class MakepaymentsServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
            //Pass Json body to servlet. (Different encoding schema.)Reference: https://www.edureka.co/community/31716/httpservletrequest-get-json-post-data
            //It's the stat.data json format.
        StringBuilder sb = new StringBuilder();
        BufferedReader br = request.getReader();
        String str = null;

        while ((str = br.readLine()) != null) {
            sb.append(str);
        }
        String json = sb.toString();
        System.out.println("Pass json test"+json);





        /*Deserialize json request to PaymentsRequest object Reference:https://www.tutorialspoint.com/gson/gson_first_application.html
         I tired to follow the above tutorial to to change like this directly as below:
         GsonBuilder builder = new GsonBuilder();
         builder.setPrettyPrinting();

         Gson gson = builder.create();
         Student student = gson.fromJson(json, PaymentsRequest.class);

         However, as i went on, there existed bugs in the following API calls, It seems only working for simple card payment but not for alipay
         or 3dS2 secure. The inner structure of paymentmethods are different with these types.

        */

        /* This is the clone example code to user Gson to add required information to payment request. But tired to avoid using this
         It's using the customer adapter which is much eaiser, example:

         GsonBuilder builder = new GsonBuilder();
         builder.registerTypeAdapter(Student.class, new StudentAdapter());
         Gson gson = builder.create();
         Learend from link:https://www.tutorialspoint.com/gson/gson_custom_adapters.htm

         <Example clone code>
        GsonBuilder builder = new GsonBuilder();
        if (json.contains("paypal")) {

            builder.registerTypeAdapter(PaymentMethodDetails.class, new PayPalDetailsDeserializer());
        } else if (json.contains("ach")) {
            builder.registerTypeAdapter(PaymentMethodDetails.class, new AchDetailsDeserializer());
        } else {
            builder.registerTypeAdapter(PaymentMethodDetails.class, new PaymentMethodDetailsDeserializer());
        }

        Gson gson1 = builder.create();
        PaymentsRequest prequest = gson1.fromJson(json, PaymentsRequest.class);
        <Example clone code>
        */

         /*If the paymentmethod passing from fontend json format includes other type, such as arry,object, may use the following to get the detail.
        This methods would be much eaiser used in all parts if I learned earlier:https://www.tutorialspoint.com/gson/gson_tree_model.html.
        As i passed the stata.data.paymentMethod value directly from frontend.So there is no need to use model tree. But finally i found out, i could not
        escape it in makepaymentdetaails step. And especially if using redirect, paymentDetailsrequest.paymentMethod is different depending on get or post request.
        JsonElement rootNode = JsonParser.parseString(json);
         JsonObject details=rootNode.getAsJsonObject();
         details.get("")
         details.getAsJsonArray("array name)
         details.getAsJsonObject("objectname").get("");
        */

        /*By Checking the code, I figured out that different type have different paymentMethods information.
        So i have a try to get what the difference of card and aliply seperate them based on
        card type. In this scenario, there should be only two alipay and scheme.
       */
        DefaultPaymentMethodDetails paymentMethodDetails = new DefaultPaymentMethodDetails();
        JSONObject ob = null;
        JSONObject obj=null;
        try {
            obj=Schemecardmethod.getPaymentDetailsObject(json);
            System.out.println("55555");

        } catch (JSONException e) {
            e.printStackTrace();
        }

        if(json.contains("\"type\":\"alipay\""))//as show in word document, alipay only has one parameter type.
        {
            paymentMethodDetails.setType("alipay");
        }else//As show in word document, a sample card should include folllowing information.
            {
            try {
                System.out.print(obj.getString("type"));

                paymentMethodDetails.setType(obj.getString("type"));
                paymentMethodDetails.setHolderName("holderName");
                paymentMethodDetails.setEncryptedCardNumber(obj.getString("encryptedCardNumber"));
                paymentMethodDetails.setEncryptedExpiryMonth(obj.getString("encryptedExpiryMonth"));
                paymentMethodDetails.setEncryptedExpiryYear(obj.getString("encryptedExpiryYear"));
                paymentMethodDetails.setEncryptedSecurityCode(obj.getString("encryptedSecurityCode"));
                paymentMethodDetails.setBrand(obj.getString("brand"));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
       PaymentsRequest prequest=new PaymentsRequest();
        prequest.setPaymentMethod(paymentMethodDetails);

        String presponse = Payments.makePayment(prequest);

        System.out.println("/nmakepaymentsresponse"+presponse);
        //System.out.println("============");
        //test Paymentdata
        //System.out.println("test987"+getServletConfig().getServletContext().getAttribute("paymentdata"));
        //Pass String post response in servlet to frontend. Reference:https://beginnersbook.com/2013/05/servlet-response/
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println(presponse);
        out.close();



    }

}
