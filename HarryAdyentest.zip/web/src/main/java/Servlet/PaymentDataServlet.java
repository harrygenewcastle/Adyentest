package Servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

/* This servlet is to store action.paymentdata without responding anything */
@WebServlet(urlPatterns = "/paymentdata.do")
public class PaymentDataServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        //Test to chekc if getting the correct paymentData
        StringBuilder sb = new StringBuilder();
        BufferedReader br = request.getReader();
        String str = null;

        while ((str = br.readLine()) != null) {
            sb.append(str);
        }
        String json = sb.toString();

        //Store the paymentdata to server when the application is running
        //Reference:https://stackoverflow.com/questions/123657/how-can-i-share-a-variable-or-object-between-two-or-more-servlets
        this.getServletConfig().getServletContext().setAttribute("paymentdata",json);

        System.out.print("+++++");
        System.out.println(json);
        System.out.print("——————");



    }
}