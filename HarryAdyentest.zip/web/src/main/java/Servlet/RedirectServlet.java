package Servlet;



import com.adyen.model.checkout.PaymentMethodDetails;
import com.adyen.model.checkout.PaymentsDetailsRequest;
import com.adyen.model.checkout.PaymentsResponse;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import module.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;

@WebServlet(urlPatterns = "/redirect.do")
public class RedirectServlet extends HttpServlet {

    @Override
    // HTTP get request to handle GET request (As i am using the get request for paymentmethod for simplicity, the redirect back would be get request.)
    // However, for data protection, better to use post. https://docs.adyen.com/payment-methods/alipay/web-drop-in

    //Reference for get reqeust deployment:https://docs.adyen.com/checkout/drop-in-web#handling-redirects
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        System.out.println("Redirect.do get entered");

        //add payload OR redirectresult and paymentdata to redirect request as Json format. But as I tested for alipay,
        //it has the resultcode parameter (Details in word file),(Should it be able to give the result?). But anyway, would follow the documentation and see if the result is the same.
        //Get payload or redirectresult depening on the redirect request.
        String paylaodOrredirectResult =null;
        String id=null;
        if(request.getParameter("redirectResult")!=null){
            id="redirectResult";
            paylaodOrredirectResult =request.getParameter("redirectResult").toString();
        }else{
            id="payload";
            paylaodOrredirectResult =request.getParameter("payload").toString();
        }


        String valuesArray = "{\n" +
               "\""+id +"\""+":\""+paylaodOrredirectResult+"\""+
                "}";
        String details="\"details\":"+valuesArray;
        String paymentdata=getServletConfig().getServletContext().getAttribute("paymentdata").toString();
        String paymentdatajson="\"paymentData\":"+paymentdata;
        String requestredirect="{"+paymentdatajson+","+details+"}";

        System.out.println("alipay paymentmethoddetail:"+requestredirect);

        //Make a payments/Details request
        GsonBuilder builder =new GsonBuilder();
        builder.registerTypeAdapter(PaymentMethodDetails.class,new PaymentMethodDetailsDeserializer());
        Gson gson = builder.create();
        PaymentsDetailsRequest prequest =gson.fromJson(requestredirect, PaymentsDetailsRequest.class);
        PaymentsResponse detailedresponse= PaymentsDetails.getPaymentDetailsObject(prequest);
        String pspref =detailedresponse.getPspReference();
        String refuse=detailedresponse.getRefusalReason();
        String resultcode=detailedresponse.getResultCode().toString();



        request.getSession().setAttribute("pspref",pspref);
        request.getSession().setAttribute("refuse",refuse);
        //Shoiwng the final result to customer. More result code and actions could be referred here:
        //https://docs.adyen.com/checkout/drop-in-web?tab=http_get_1#step-6-present-payment-result
        System.out.println(resultcode);
        if(resultcode=="Authorised"){
            request.getRequestDispatcher("/success.jsp").forward(request, response);
        }else if (resultcode=="Received"){
            request.getRequestDispatcher("/pending.jsp").forward(request, response);
        }
        else {
            request.getRequestDispatcher("/failure.jsp").forward(request, response);
        }

    }

    // HTTP post request to handle POST redirect. Reference:https://docs.adyen.com/checkout/drop-in-web?tab=http_post_2#post-redirect
    // URL-decode the parameters from the form data and pass the parameters to your back end. So no need to do the decode in servlet,
    // just get the parameters.
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        System.out.println("Redirect.do post entered");

        String md=request.getParameter("MD");
        String pares=request.getParameter("PaRes");
        System.out.println("2222121"+md);
        System.out.println("33333"+pares);

        //add md, parse and paymentdata to redirect request as Json format
        String valuesArray = "{\n" +
                "\"MD\": \"" + md + "\",\n" +
                "\"PaRes\": \"" + pares + "\"\n" +
                "}";
        String details="\"details\":"+valuesArray;
        String paymentdata=getServletConfig().getServletContext().getAttribute("paymentdata").toString();
        System.out.println("12365"+paymentdata);
        String paymentdatajson="\"paymentData\":"+paymentdata;
        String requestredirect="{"+paymentdatajson+","+details+"}";

        System.out.print("+++\n"+requestredirect);

        //Make a payments/Details request
        GsonBuilder builder =new GsonBuilder();
        builder.registerTypeAdapter(PaymentMethodDetails.class,new PaymentMethodDetailsDeserializer());
        Gson gson = builder.create();
        PaymentsDetailsRequest prequest =gson.fromJson(requestredirect, PaymentsDetailsRequest.class);
        PaymentsResponse detailedresponse= PaymentsDetails.getPaymentDetailsObject(prequest);
        String pspref =detailedresponse.getPspReference();
        String refuse=detailedresponse.getRefusalReason();
        String resultcode=detailedresponse.getResultCode().toString();

        request.getSession().setAttribute("pspref",pspref);
        request.getSession().setAttribute("refuse",refuse);
        //Shoiwng the final result to customer. More result code and actions could be referred here:
        //https://docs.adyen.com/checkout/drop-in-web?tab=http_get_1#step-6-present-payment-result
        if(resultcode=="Authorised"){
            System.out.println("hello harry");
            request.getRequestDispatcher("/success.jsp").forward(request, response);
        }else if (resultcode=="Received"){
            request.getRequestDispatcher("/pending.jsp").forward(request, response);
        }
        else {
            request.getRequestDispatcher("/failure.jsp").forward(request, response);
        }





    }
}
