package module;

import com.adyen.model.checkout.DefaultPaymentMethodDetails;
import org.json.*;


//Scheme card methods data referred to word ducument
public class Schemecardmethod {
    public static JSONObject getPaymentDetailsObject(String data) throws JSONException {

            System.out.print("12345");
            JSONObject obj = new JSONObject(data);
            System.out.println("1234456");
            /*String type=obj.getString("type");
            String holderName=obj.getString("HolderName");
            String encryptedCardNumber = obj.getString("encryptedCardNumber");
            String encryptedExpiryMonth=obj.getString("encryptedExpiryMonth");
            String encryptedExpiryYear =obj.getString("encryptedExpiryYear");
            String encryptedSecurityCode=obj.getString("encryptedSecurityCode")
            String brand=obj.getString("brand");
            */

           return obj;
    }
};
