package module;

import com.adyen.Client;
import com.adyen.enums.Environment;
import com.adyen.model.checkout.PaymentsDetailsRequest;
import com.adyen.model.checkout.PaymentsResponse;
import com.adyen.service.Checkout;
import com.adyen.service.exception.ApiException;
import com.google.gson.Gson;

import java.io.IOException;

//Refer to :https://docs.adyen.com/checkout/drop-in-web#step-5-additional-payment-details

public class PaymentsDetails{

    public static  String makePaymentDetailsRequest(PaymentsDetailsRequest paymentsDetailsRequest) {
        String apiKey = "AQEyhmfxLI3MaBFLw0m/n3Q5qf3VaY9UCJ14XWZE03G/k2NFitRvbe4N1XqH1eHaH2AksaEQwV1bDb7kfNy1WIxIIkxgBw==-y3qzswmlmALhxaVPNjYf74bqPotG12HroatrKA066yE=-W+t7NF;s4}%=kUSD";

        Client client = new Client(apiKey, Environment.TEST);
        Checkout checkout = new Checkout(client);
        PaymentsResponse paymentsDetailsResponse=null;
        String paymentsDetailsResponsefield=null;
        try {
            paymentsDetailsResponse = checkout.paymentsDetails(paymentsDetailsRequest);
            Gson gson =new Gson();
            paymentsDetailsResponsefield = gson.toJson(paymentsDetailsResponse);
            return paymentsDetailsResponsefield;
        }catch(ApiException | IOException e){
            return e.toString();
        }finally {
            System.out.println("paydetail response"+paymentsDetailsResponsefield);
        }


    };

    //This static method is for RedirectServelt to make a detailedpayment request and get response.
    public static PaymentsResponse getPaymentDetailsObject(PaymentsDetailsRequest paymentsDetailsRequest){
        String apiKey = "AQEyhmfxLI3MaBFLw0m/n3Q5qf3VaY9UCJ14XWZE03G/k2NFitRvbe4N1XqH1eHaH2AksaEQwV1bDb7kfNy1WIxIIkxgBw==-y3qzswmlmALhxaVPNjYf74bqPotG12HroatrKA066yE=-W+t7NF;s4}%=kUSD";

        Client client = new Client(apiKey, Environment.TEST);
        Checkout checkout = new Checkout(client);
        PaymentsResponse paymentsDetailsResponse=null;
        String paymentsDetailsResponsefield=null;
        try {
            paymentsDetailsResponse = checkout.paymentsDetails(paymentsDetailsRequest);
            return paymentsDetailsResponse;
        }catch(ApiException | IOException e){
            e.printStackTrace();
        }
        return paymentsDetailsResponse;
    };


}
