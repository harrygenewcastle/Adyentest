package module;

import com.adyen.Client;
import com.adyen.enums.Environment;
import com.adyen.model.Amount;
import com.adyen.model.BrowserInfo;
import com.adyen.model.checkout.PaymentsRequest;
import com.adyen.model.checkout.PaymentsResponse;
import com.adyen.service.Checkout;
import com.adyen.service.exception.ApiException;
import com.google.gson.Gson;

import java.io.IOException;

//Refer to:https://docs.adyen.com/checkout/drop-in-web#step-3-make-a-payment
//5 parameters are required: mechantAccount, amount,reference,paymentMethod, returnURL
public class Payments {

    public static String makePayment(PaymentsRequest paymentsRequest) {
        String type = paymentsRequest.getPaymentMethod().getType();
        // Set your X-API-KEY with the API key from the Customer Area.
        String xApiKey = "AQEyhmfxLI3MaBFLw0m/n3Q5qf3VaY9UCJ14XWZE03G/k2NFitRvbe4N1XqH1eHaH2AksaEQwV1bDb7kfNy1WIxIIkxgBw==-y3qzswmlmALhxaVPNjYf74bqPotG12HroatrKA066yE=-W+t7NF;s4}%=kUSD";
        Client client = new Client(xApiKey, Environment.TEST);
        Checkout checkout = new Checkout(client);

        paymentsRequest.setMerchantAccount("AdyenRecruitmentCOM");
        paymentsRequest.setChannel(PaymentsRequest.ChannelEnum.WEB);



        System.out.println("66666"+type);
        //Amount parameter is required.
        Amount amount = new Amount();
        if(type.equals("alipay")) {
            //Set currency and country code, if customer is using alipay or wechatpay
            amount.setCurrency("CNY");
            paymentsRequest.setCountryCode("CN");
        }// Add additional parameters to use native 3D Secure 2 Authentication, refer to:
        //Perform 3DS2 on all card payments, refer to:https://docs.adyen.com/checkout/3d-secure/redirect-3ds2-3ds1/web-drop-in
        // For all credit and debit cards paymentMethod.type, refer to:https://docs.adyen.com/payment-methods#credit-and-debit-cards
        //Still missing browserInfo, origin  parameters. So just add them as below:
        else if (type.equals("scheme")) {
            amount.setCurrency("EUR");
            paymentsRequest.setCountryCode("EUR");
            paymentsRequest.setOrigin("http://localhost:8080");
            paymentsRequest.putAdditionalDataItem("allow3DS2", "true");

            //For browserinfo settings, Referred to the same link:https://docs.adyen.com/checkout/3d-secure/redirect-3ds2-3ds1/web-drop-in
            BrowserInfo browserInfo = new BrowserInfo();
            browserInfo.setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36");
            browserInfo.setAcceptHeader("text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8");
            browserInfo.setLanguage("nl-NL");
            browserInfo.setColorDepth(24);
            browserInfo.setScreenHeight(723);
            browserInfo.setScreenWidth(1536);
            browserInfo.setTimeZoneOffset(0);
            browserInfo.setJavaEnabled(true);
            paymentsRequest.setBrowserInfo(browserInfo);

        }
        else {
            amount.setCurrency("EUR");
            paymentsRequest.setCountryCode("EUR");
        }
        amount.setValue(1000L);
        paymentsRequest.setAmount(amount);


        System.out.print(paymentsRequest.getAmount().getCurrency()+" and "+paymentsRequest.getCountryCode());
        paymentsRequest.setReference("{Harry}_checkoutChallenge");
        paymentsRequest.setReturnUrl("http://localhost:8080/redirect.do");




        try {
            PaymentsResponse paymentsResponse = checkout.payments(paymentsRequest);
            //Serialize paymentsResponse object to json String
            Gson gson = new Gson();
            String response = gson.toJson(paymentsResponse);
            //System.out.println("step1" + response);
            return response;
        } catch (ApiException | IOException e) {
            return e.toString();
        }
    }
}
