package module;

import com.adyen.Client;
import com.adyen.enums.Environment;
import com.adyen.model.Amount;
import com.adyen.model.checkout.PaymentMethodsRequest;
import com.adyen.model.checkout.PaymentMethodsResponse;
import com.adyen.service.Checkout;
import com.adyen.service.exception.ApiException;
import com.google.gson.Gson;


import java.io.IOException;

public class PaymentMethods {
    public static String getPaymentMethods(String type)  {

        String xApiKey = "AQEyhmfxLI3MaBFLw0m/n3Q5qf3VaY9UCJ14XWZE03G/k2NFitRvbe4N1XqH1eHaH2AksaEQwV1bDb7kfNy1WIxIIkxgBw==-y3qzswmlmALhxaVPNjYf74bqPotG12HroatrKA066yE=-W+t7NF;s4}%=kUSD";
        Client client = new Client(xApiKey, Environment.TEST);
        Checkout checkout = new Checkout(client);
        PaymentMethodsRequest paymentMethodsRequest = new PaymentMethodsRequest();
        paymentMethodsRequest.setMerchantAccount("AdyenRecruitmentCOM");

        Amount amount = new Amount();
        /*Show Alipay in my payment form. Refer to:https://docs.adyen.com/payment-methods/alipay/web-drop-in#show-alipay-in-your-payment-form
        However as tested, it seems that by default alipay would shop up even with the following two parameters not set*/
        paymentMethodsRequest.setCountryCode("CN");
        amount.setCurrency("EUR");

        amount.setValue(1000L);
        paymentMethodsRequest.setAmount(amount);
        paymentMethodsRequest.setChannel(PaymentMethodsRequest.ChannelEnum.WEB); // Device is the Web

        try {
            PaymentMethodsResponse paymentMethodsResponse = checkout.paymentMethods(paymentMethodsRequest);

            //Change object to Json string using Gson. Refer to:https://blog.codota.com/how-to-convert-a-java-object-into-a-json-string/
            Gson gson = new Gson();
            String paymentMethodsResponseStringified = gson.toJson(paymentMethodsResponse);
            return paymentMethodsResponseStringified;
        }catch(ApiException | IOException e) {
            return e.toString();
        }

    }
}
